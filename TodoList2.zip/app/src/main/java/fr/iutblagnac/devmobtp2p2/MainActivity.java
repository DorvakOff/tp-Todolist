package fr.iutblagnac.devmobtp2p2;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import fr.iutblagnac.devmobtp2p2.adapter.TodoListAdapter;
import fr.iutblagnac.devmobtp2p2.model.Todo;
import fr.iutblagnac.devmobtp2p2.model.TodoListData;

public class MainActivity extends AppCompatActivity {

    private TodoListAdapter tlAdapter;
    private TodoListData tld;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tld = new TodoListData();
        tlAdapter = new TodoListAdapter(this, tld);

        ListView lvTodo = findViewById(R.id.lv_todo_list);
        lvTodo.setAdapter(tlAdapter);

        this.registerForContextMenu(lvTodo);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        MenuInflater inflater = getMenuInflater();

        menu.setHeaderTitle(getResources().getString(R.string.listview_menu_title));

        inflater.inflate(R.menu.list_todo_menu, menu);

        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int index = info.position;

        Todo todo = tlAdapter.getItem(index);

        if (item.getItemId() == R.id.listview_menu_delete_todo_id) {
            handleDeleteTodoItem(todo);
            return true;
        } else if (item.getItemId() == R.id.listview_menu_modify_todo_id) {
            Toast.makeText(this, "Modification " + todo, Toast.LENGTH_SHORT).show();
        } else if (item.getItemId() == R.id.listview_menu_show_todo_id) {
            Toast.makeText(this, "Affichage" + todo, Toast.LENGTH_SHORT).show();
        }

        return super.onContextItemSelected(item);
    }

    private void handleDeleteTodoItem(Todo todo) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.listview_menu_delete_todo_title));
        builder.setMessage(todo.getTitle() + " : " + todo.getTodo());
        builder.setPositiveButton(getResources().getString(R.string.ok), (dialog, which) -> {
            tld.removeById(todo.getId());
            tlAdapter.notifyDataSetChanged();
            dialog.dismiss();
        });
        builder.setNegativeButton(getResources().getString(R.string.cancel), (dialog, which) -> {
            dialog.cancel();
        });
        builder.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_options, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.main_menu_ajouter_todo_id) {
            Toast.makeText(this, "Ajouter un todo", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}